<?php

$db = new SQLite3('/home/ragdelaed/gits/pystemon/db.sqlite3') or die('Unable to open database');
$result = $db->query('SELECT * FROM pasties where matches != ""') or die('Query failed');
while ($row = $result->fetchArray())
{
  echo "Site: {$row['site']}\nURL: {$row['url']}\nMatches: {$row['matches']}\n";
}

?>
