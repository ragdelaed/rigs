<?php
	// include Database connection file 
	include("db_connection.php");

	// Design initial table header 
    $data='                        <thead>
                          <tr>
                            <th>Site</th>
                            <th>ID</th>
                            <th>md5</th>
                            <th>URL</th>
                            <th>Local Path</th>
                            <th>Time Stamp</th>
                            <th>Matches</th>
                          </tr>
                        </thead>
                        <tbody>';
    $data .="\n";


    // if query results contains rows then fetch those rows 
    if ($result = $db->query("select site,id,md5,url,local_path,timestamp,matches from pasties order by matches desc limit 5")) {
    	$number = 1;
    while ($row = $result->fetch_assoc()) {
                $data .= '                          <tr>
                                <td>'.$row['site'].'</td>
                                <td>'.$row['id'].'</td>
                                <td>'.$row['md5'].'</td>
                                <td><a href='.$row['url'].' target=_>URL  </td>
                                <td>'.$row['local_path'].'</td>
                                <td>'.$row['timestamp'].'</td>
                                <td>'.$row['matches'].'</td>
                          </tr>';
                $data .="\n";
    		$number++;
    	}
    }
    else
    {
    	// records now found 
    	$data .= '<tr><td colspan="8">Records not found!</td></tr>';
    }

    $data .= '                      </tbody>';
    echo $data;
?>
